#ifndef __TASKADC_H__
#define __TASKADC_H__

#include "fm33lc0xx_fl.h"

extern void AdcTask(void *pvParameters);
#endif 
