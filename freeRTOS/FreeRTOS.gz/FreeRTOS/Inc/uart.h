#ifndef __UART_H__
#define __UART_H__

#include "fm33lc0xx_fl.h"

extern void DebugInit(void);
#endif 
