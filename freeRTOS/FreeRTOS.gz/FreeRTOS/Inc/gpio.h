#ifndef __GPIO_H__
#define __GPIO_H__

#include "fm33lc0xx_fl.h"

extern void GPIO_interrupt_init(void);
#endif 
