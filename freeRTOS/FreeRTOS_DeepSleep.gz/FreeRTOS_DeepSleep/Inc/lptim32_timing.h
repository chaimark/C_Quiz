#ifndef __DEMO_LPTIM32_TIMING_H__
#define __DEMO_LPTIM32_TIMING_H__

#include "fm33lc0xx_fl.h"

extern void LPTIM32_Init(void);

#endif
