#ifndef __TICKLESSHOOK_H__
#define __TICKLESSHOOK_H__

#include "main.h"
#include "FreeRTOS.h"
extern void vApplicationSleep ( TickType_t xExpectedIdleTime );
#endif 
